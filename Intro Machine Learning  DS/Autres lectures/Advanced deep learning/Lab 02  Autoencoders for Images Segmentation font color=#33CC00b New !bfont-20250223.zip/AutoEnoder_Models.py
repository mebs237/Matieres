# ************           UNET ARCHITECTURE         **********************

class UNet(nn.Module):
    def __init__(self, input_channels=3, output_channels=1):
        super(UNet, self).__init__()

        # Encoder
        self.enc1 = self._down_block(input_channels, 64)
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.enc2 = self._down_block(64, 128)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.enc3 = self._down_block(128, 256)
        self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.enc4 = self._down_block(256, 512)
        self.pool4 = nn.MaxPool2d(kernel_size=2, stride=2)
        # Bottleneck
        self.bottleneck = self._conv_block(512, 1024)

        # Decoder
        self.up1 = nn.ConvTranspose2d(1024, 512, kernel_size=2, stride=2)
        self.dec1 = self._conv_block(1024, 512)
        self.up2 = nn.ConvTranspose2d(512, 256, kernel_size=2, stride=2)
        self.dec2 = self._conv_block(512, 256)
        self.up3 = nn.ConvTranspose2d(256, 128, kernel_size=2, stride=2)
        self.dec3 = self._conv_block(256, 128)
        self.up4 = nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2)
        self.dec4 = self._conv_block(128, 64)

        # output layer
        self.outconv = nn.Conv2d(64, output_channels, kernel_size=1)

    # Encoder block
    def _down_block(self, in_channels, out_channels):
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.ELU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.ELU()
        )

    # Decoder  block
    def _conv_block(self, in_channels, out_channels):
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.ELU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.ELU()
        )

    def forward(self, x):
        c1 = self.enc1(x)
        p1 = self.pool1(c1)
        c2 = self.enc2(p1)
        p2 = self.pool2(c2)
        c3 = self.enc3(p2)
        p3 = self.pool3(c3)
        c4 = self.enc4(p3)
        p4 = self.pool4(c4)

        # Bottleneck
        bottleneck = self.bottleneck(p4)
        u1 = self.up1(bottleneck)
        d1 = self.dec1(torch.cat([u1, c4], dim=1))
        u2 = self.up2(d1)
        d2 = self.dec2(torch.cat([u2, c3], dim=1))
        u3 = self.up3(d2)
        d3 = self.dec3(torch.cat([u3, c2], dim=1))
        u4 = self.up4(d3)
        d4 = self.dec4(torch.cat([u4, c1], dim=1))


        out = self.outconv(d4)
        out = F.sigmoid(out)
        return out


# ************           LinkNet ARCHITECTURE         **********************
 
import torchvision.models.resnet as resnet
class LinkNet(nn.Module):
    def __init__(self, num_classes, num_channels=3):
        super().__init__()
        filters = [64, 128, 256, 512]
        res = resnet.resnet34(pretrained=True)

        # Encoder
        self.firstconv = res.conv1
        self.firstbn = res.bn1
        self.firstrelu = res.relu
        self.firstmaxpool = res.maxpool
        self.encoder1 = res.layer1
        self.encoder2 = res.layer2
        self.encoder3 = res.layer3
        self.encoder4 = res.layer4

        # Decoder
        self.decoder4 = self._decoder_block(filters[3], filters[2])
        self.decoder3 = self._decoder_block(filters[2], filters[1])
        self.decoder2 = self._decoder_block(filters[1], filters[0])
        self.decoder1 = self._decoder_block(filters[0], filters[0])

        # Final Classifier
        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 3, stride=2)
        self.finalconv2 = nn.Conv2d(32, 32, 3)
        self.finalconv3 = nn.Conv2d(32, num_classes, 2, padding=1)
        self.relu = nn.ReLU()

    def _decoder_block(self, in_channels, n_filters):
        return nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 4, kernel_size=1),
            nn.BatchNorm2d(in_channels // 4),
            nn.ReLU(),
            nn.ConvTranspose2d(in_channels // 4, in_channels // 4, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.BatchNorm2d(in_channels // 4),
            nn.ReLU(),
            nn.Conv2d(in_channels // 4, n_filters, kernel_size=1),
            nn.BatchNorm2d(n_filters),
            nn.ReLU()
        )

    def forward(self, x):
        # Encoder
        x = self.firstconv(x)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x = self.firstmaxpool(x)
        e1 = self.encoder1(x)
        e2 = self.encoder2(e1)
        e3 = self.encoder3(e2)
        e4 = self.encoder4(e3)

        # Decoder with Skip Connections
        d4 = self.decoder4(e4) + e3
        d3 = self.decoder3(d4) + e2
        d2 = self.decoder2(d3) + e1
        d1 = self.decoder1(d2)

        # Final Classification
        x = self.finaldeconv1(d1)
        x = self.relu(x)
        x = self.finalconv2(x)
        x = self.relu(x)
        x = self.finalconv3(x)
        out = F.sigmoid(x)

        return out
 
# ************           DeepLabV3 ARCHITECTURE         ********************** 
 
# Load the pretrained DeepLabV3 model
deeplabv3 = torch.hub.load('pytorch/vision:v0.10.0', 'deeplabv3_resnet50', pretrained=True)

deeplabv3.classifier[4] = nn.Sequential(
    nn.Conv2d(256, 1, kernel_size=1),
    nn.Sigmoid()                      # Add Sigmoid activation
)

deeplabv3.aux_classifier[4] = nn.Sequential(
        nn.Conv2d(256, 1, kernel_size=1),
        nn.Sigmoid()                      # Add Sigmoid activation
    )