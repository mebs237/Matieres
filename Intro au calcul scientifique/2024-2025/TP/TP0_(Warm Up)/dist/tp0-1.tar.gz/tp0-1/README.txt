Stela Meyouguem
Jospin Nzangue
Roland Djamgoum Wannou
Célestin Antoine
Rachel Maes
Prestonne Mebou


Veillez à une bonne analyse du problème, à la justification des vos
décisions et à la clarté du code et des explications.


python setup.py build ⇒ doit « compiler » votre projet.

python setup.py sdist
⇒ crée un tarball qui se trouvera dans « dist/ ».  Les fichiers qui
sont inclus sont controlés par « MANIFEST.in » (pas besoin d'y toucher
normalement).
