Mebou Prestonne
Abanda Nathan
Antoine Célestin
Smeets Maxime


python setup.py build ⇒ doit « compiler » votre projet.

python setup.py sdist
⇒ crée un tarball qui se trouvera dans « dist/ ».  Les fichiers qui
sont inclus sont controlés par « MANIFEST.in » (pas besoin d'y toucher
normalement).
