# Rapport d'analyse : Python_Generator

## Statistiques globales

|                 |        value |
|:----------------|-------------:|
| mean_p_value    |     0.510352 |
| mmedian_p_value |     0.514124 |
| std_p_value     |     0.288384 |
| mean_accept     |     0.953689 |
| median_accept   |     1        |
| std_accept      |     0.210162 |
| alpha           |     0.05     |
| n_tests         | 20600        |

- P-value moyenne globale : 0.510 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.506, 0.514]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 95.4% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [95.082%, 95.656%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par test
| Test         |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test    |       0.502871 |         0.502871 |      0.95165  |               1 |     0.214514 |      0.287133 |   10300 |
| (nb_bins=10) |                |                  |               |                 |              |               |         |
| K-S_Test     |       0.517834 |         0.517834 |      0.955728 |               1 |     0.205708 |      0.28945  |   10300 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.503 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.497, 0.508]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 95.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [94.751%, 95.579%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour le K-S_Test 
- P-value moyenne globale : 0.518 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.512, 0.523]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 95.6% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [95.176%, 95.970%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|           100 |       0.50992  |         0.514124 |       0.95355 |               1 |     0.210463 |      0.288591 |   20000 |
|          5000 |       0.503759 |         0.505536 |       0.96    |               1 |     0.196205 |      0.283915 |     400 |
|         10000 |       0.566727 |         0.602649 |       0.955   |               1 |     0.207824 |      0.271695 |     200 |


### Pour size = 100.0 
- P-value moyenne globale : 0.510 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.506, 0.514]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 95.4% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [95.063%, 95.647%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



### Pour size = 5000.0 
- P-value moyenne globale : 0.504 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.476, 0.532]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 96.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [94.077%, 97.923%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour size = 10000.0 
- P-value moyenne globale : 0.567 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.529, 0.604]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 95.5% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [92.620%, 98.380%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests


