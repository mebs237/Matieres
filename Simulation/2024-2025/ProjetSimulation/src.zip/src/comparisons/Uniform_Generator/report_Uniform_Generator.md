# Rapport d'analyse : Uniform_Generator

## Statistiques globales

|                 |        value |
|:----------------|-------------:|
| mean_p_value    |     0.515222 |
| mmedian_p_value |     0.523354 |
| std_p_value     |     0.287619 |
| mean_accept     |     0.957184 |
| median_accept   |     1        |
| std_accept      |     0.202446 |
| alpha           |     0.05     |
| n_tests         | 20600        |

- P-value moyenne globale : 0.515 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.511, 0.519]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 95.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [95.442%, 95.995%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par test
| Test         |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test    |       0.506739 |         0.506739 |      0.952718 |               1 |     0.212251 |      0.285033 |   10300 |
| (nb_bins=10) |                |                  |               |                 |              |               |         |
| K-S_Test     |       0.523705 |         0.523705 |      0.96165  |               1 |     0.192048 |      0.289948 |   10300 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.507 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.501, 0.512]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 95.3% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [94.862%, 95.682%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour le K-S_Test 
- P-value moyenne globale : 0.524 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.518, 0.529]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 96.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [95.794%, 96.536%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|           100 |       0.514712 |         0.520807 |       0.95725 |               1 |     0.202298 |      0.287404 |   20000 |
|          5000 |       0.548481 |         0.590456 |       0.96    |               1 |     0.196205 |      0.293001 |     400 |
|         10000 |       0.49973  |         0.543342 |       0.945   |               1 |     0.228552 |      0.295358 |     200 |


### Pour size = 100.0 
- P-value moyenne globale : 0.515 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.511, 0.519]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 95.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [95.445%, 96.005%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



### Pour size = 5000.0 
- P-value moyenne globale : 0.548 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.520, 0.577]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 96.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [94.077%, 97.923%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour size = 10000.0 
- P-value moyenne globale : 0.500 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.459, 0.541]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 94.5% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [91.332%, 97.668%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests


