# Rapport comparatif des générateurs

## Statistiques globales

|                   |   mean_p_value |   mmedian_p_value |   std_p_value |   mean_accept |   median_accept |   std_accept |   alpha |
|:------------------|---------------:|------------------:|--------------:|--------------:|----------------:|-------------:|--------:|
| Uniform_Generator |         0.5152 |            0.5234 |        0.2876 |        0.9572 |               1 |       0.2024 |    0.05 |
| Python_Generator  |         0.5104 |            0.5141 |        0.2884 |        0.9537 |               1 |       0.2102 |    0.05 |

