"""
Module des fonctions pour l'analyse automatique des séquences , l'evaluation automatique des générateurs

"""

import json
from dataclasses import dataclass , field
from pathlib import Path
from typing import List, Dict, Optional, Union , Literal
from enum import Enum
from collections import namedtuple
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from numpy.typing import NDArray
from scipy.stats import norm
from Tests import Tests , Chi2Test , KSTest
from Generators import Generators

ComputeRes = namedtuple("res_compute", ["hist_df", "stats", "window_sizes"])

def analyse_sequence(sequence: NDArray,
                     tests: Optional[List[Tests]] = None,
                     alpha: float = 0.05,
                     granularities: Optional[List[Union[int, float]]] = None) -> ComputeRes:
    """
    fait les calculs de l'analyse de la séquence
    """

    tests = tests if tests else [Chi2Test(), KSTest()]

    n = len(sequence)

    granularities = granularities if granularities else [1.0]
    # fixer les tailles des fenêtre wind_sizes
    window_sizes = to_wind_size(granularities,n)
    results = []
    for test in tests:
        for w in window_sizes:
            # Découper la séquence en sous séquence de taille wind_size
            for i in range(0,n-w +1 , w):
                sub_seq = sequence[i:i+w]
                test_result = test.test(sub_seq, alpha)
                res = {
                "Test" : str(test),
                "window_start" : i,
                "window_size" : w,
                "p_value" : test_result.p_value,
                "stat_obs" : test_result.stat_obs,
                "stat_crit" : test_result.stat_crit,
                "accept" : test_result.accept
                }
                results.append(res)
    columns = ["Test", "window_size" , "window_start" , "p_value", "accept","stat_obs","stat_crit"]
    hist_df = pd.DataFrame(results,columns=columns)

    stats = {
        "mean_p_value": hist_df["p_value"].mean(),
        "median_p_value": hist_df["p_value"].median(),
        "std_p_value": hist_df["p_value"].std(),
        "mean_accept": hist_df["accept"].mean(),
        "median_accept": hist_df["accept"].median(),
        "std_accept": hist_df["accept"].std(),
    }

    return ComputeRes(hist_df , stats , window_sizes)

def to_wind_size(granularities: List[Union[int,float]],
                 len_seq: int
                 )->List[int]:
    """
    Transforme une granularité ou liste de granularités en taille(s) entière(s) de sous séquence
    """
    if len_seq<=0:
        raise ValueError("la taillle de la séquence doit être > 0")

    # Vérifier si les granularités sont des entiers ou des fractions
    if np.all([isinstance(g,int) and 0<g<=len_seq for g in granularities]) :
        return granularities
    elif np.all([isinstance(g,float) and 0.0<g<=1.0 for g in granularities]):
        return [int(g*len_seq) for g in granularities]
    else :
        raise ValueError(f"les granularités doivent être > 0 ,  être soit des entiers <={len_seq} , soit des fractions  <=1 de la taille de ")

def evaluate_generator(generator : Generators ,
                       tests:Optional[List[Tests]] = None,
                       alpha: float = 0.05 ,
                       n_repeat: int = 200,
                       seq_len: int = 10_000,
                       granularities: Optional[List[Union[int, float]]] = None
                        )->ComputeRes:
    """
    Evalue le générateur en générant n_repeat fois des séquences de taille sequence_lenght et en les analysant

    Parameters
    ----------
    generator : Generators
        générateur à evaluer
    tests : List[Tests], optional
        test à appliquer
    granularities : List[Union[int , float]], optional
        tailles des fenêtres
    alpha : float, optional
        seuil de signification
    n_repeat : int, optional
        nombre de repetition
    seq_lenght : int, optional
        taille des séquences générées à chaque itération

    Returns
    -------
        Objet contenant ;
    - hist : pd.DataFrame
        DataFrame de l'historique des resultats selon chaque test
    - stats : dict
        un résumé statistiques globales
    """

    all_results = []
    for i in range(n_repeat):
        seq = generator.generate(seq_len)
        res = analyse_sequence(sequence=seq ,
                               alpha=alpha ,
                               tests=tests , granularities=granularities)
        res.hist_df["Iteration"]=i
        all_results.append(res.hist_df)

    df = pd.concat(all_results,ignore_index=True)

    stats = {
        "mean_p_value":df["p_value"].mean(),
        "mmedian_p_value":df["p_value"].median(),
        "std_p_value":df["p_value"].std(),
        "mean_accept":df["accept"].mean(),
        "median_accept":df["accept"].median(),
        "std_accept":df["accept"].std(),
        "alpha": alpha
        }

    return ComputeRes(hist_df=df,stats=stats,
                      window_sizes=res.window_sizes)

@dataclass
class status(Enum):
    Normal = "normal"
    High = "high"
    Low = "low"

@dataclass
class SequenceAnalyzer:
    """
    Classe permettant l'encapsulation des résultats d'analyse d'une séquence afin de les manipuler pour :
        * créer , afficher et sauvegarder  des graphiques
        * generation et sauvegarde d'un rapport d'interpretation

    Attributs
    -------
    sequence :
        séquence à analyser
    test :
        liste des tests à appliquer
    alpha :
        seuil de signification
    granularities :
        parmètres  fixant les tailles des fenêtres ; si ``NONE`` , on fait une analyse globale
    name :
        titre de l'analyse (pour les tableaux et les graphiques)
    hist_df (pd.DataFrame):
        historique des calculs de l'analyse de la séquence
    stats (dict):
        résumé aggrégé des statistiques
    window_sizes (List[int]):
        liste des taille de sous séquence utilisées
    """

    sequence:NDArray
    tests : Optional[List[Tests]] = None
    alpha : float = 0.05
    granularities:List[Union[int,float]]= None
    name : Optional[str] = None
    _increment : int = 0

    def __post_init__(self):
        if not self.name:
            self.name = f"Result_{self.__class__._increment}"
        self.__class__._increment += 1
        res = analyse_sequence(
            sequence=self.sequence,
            tests=self.tests,
            alpha=self.alpha,
            granularities=self.granularities
        )
        self.hist_df: pd.DataFrame = res.hist_df
        self.stats: Dict[str, float] = res.stats
        self.window_sizes: List[int] = res.window_sizes

    def __str__(self) -> str:
        """Représentation string de l'analyse"""
        return self.name

    @property
    def hist_test(self)->pd.DataFrame:
        """ aggregation des résultats par test"""
        hist_count = self.hist_df.groupby("Test").size().reset_index(name='Count')
        hist = self.hist_df.copy().groupby("Test").agg(
            mean_p_value =("p_value","mean"),
            median_p_value = ("p_value","mean"),
            mean_accept = ("accept","mean"),
            median_accept = ("accept","median"),
            std_accept = ("accept","std"),
            std_p_value = ("p_value","std")
        ).reset_index()
        return hist.merge(hist_count, on="Test").sort_values("Test")

    @property
    def hist_granularity(self)->pd.DataFrame:
        """ aggregation des résultats par granularité"""
        hist_count = self.hist_df.groupby("window_size").size().reset_index(name='Count')
        # Calcul des statistiques par granularité
        hist = self.hist_df.copy().groupby("window_size").agg(
            mean_p_value = ("p_value","mean") ,
            median_p_value = ("p_value","median"),
            mean_accept = ("accept","mean"),
            median_accept = ("accept","median"),
            std_accept = ("accept","std"),
            std_p_value = ("p_value","std")
        ).reset_index()
        return hist.merge(hist_count, on="window_size").sort_values("window_size")

    def generate_report(self,gran:bool=True,test:bool=True) -> str:
        """
        Génère un rapport au format Markdown.
        """
        report = f"# Rapport d'analyse : {self.name}\n\n"

        # Statistiques globales
        report += "## Statistiques globales\n\n"
        stats_with_n = self.stats.copy()
        stats_with_n["n_tests"] = self.hist_df.shape[0]  # Ajouter le nombre de tests
        report += pd.DataFrame([stats_with_n]).T.rename(columns={0:"value"}).to_markdown() + "\n\n"

        report+=  self.interpret_stats(stats_with_n) + "\n\n"

        if test:
            # Analyse par test
            report += "\n## statistiques par test\n"
            report += self.hist_test.to_markdown(index=False)+ "\n\n"

            for _, row in self.hist_test.iterrows():
                stats_i = {
                    "mean_p_value": row['mean_p_value'],
                    "mean_accept": row['mean_accept'],
                    "std_accept": row['std_accept'],
                    "std_p_value": row['std_p_value'],
                    "alpha": self.stats.get('alpha', 0.05),
                    "n_tests": row['Count']
                }
                report += f"\n### Pour le {row['Test']} \n"
                report += self.interpret_stats(stats_i) + "\n\n"

        if gran:
            # resultat par granularité
            report += "\n## statistiques par granularité\n"
            report += self.hist_granularity.to_markdown(index=False) + "\n\n"

            for _, row in self.hist_granularity.iterrows():
                stats_i = {
                    "mean_p_value": row['mean_p_value'],
                    "mean_accept": row['mean_accept'],
                    "std_accept": row['std_accept'],
                    "std_p_value": row['std_p_value'],
                    "alpha": self.stats.get('alpha', 0.05),
                    "n_tests": row['Count']
                }
                report += f"\n### Pour size = {row['window_size']} \n"
                report += self.interpret_stats(stats_i) + "\n\n"



        return report
    @staticmethod
    def interpret_stats(stats: dict) -> str:
        """Interprétation des statistiques"""
        report =""
        n_tests = stats.get("n_tests" , 1) # Nombre total de tests effectués
        n_root = np.sqrt(n_tests)  # Racine carrée du nombre de tests pour les intervalles de confiance
        alpha = stats.get('alpha', 0.05)
        z = norm.ppf(1 - alpha / 2)  # Quantile pour l'intervalle de confiance
        ideal_p_value = 0.5  # P-value attendue sous H₀
        ideal_accept = 1 - alpha  # Taux d'acceptation attendu sous H₀


        # Interprétation de la p-value moyenne===
        mean_p = stats.get('mean_p_value', 0.5)
        std_p = stats.get('std_p_value', 0.0)
        lowerp , upperp = mean_p - z*std_p/n_root , mean_p + z*std_p/n_root
        report += f"- P-value moyenne globale : {mean_p:.3f} vs {ideal_p_value} attendu sous H₀ \n"
        report += f"- Intervalle de confiance à {(1-alpha):.0%} : [{lowerp:.3f}, {upperp:.3f}]\n"

        if lowerp > ideal_p_value:
            p_value_status = status.High
            report += "- P-value moyenne  élevée : sur-ajustement probable ou biais dans l'ensemble des tests utilisé \n"
        elif upperp < ideal_p_value:
            p_value_status = status.Low
            report += "- P-value moyenne faible : rejet fréquent de l'uniformité\n"
        else :
            p_value_status = status.Normal
            report += "- P-value moyenne dans l'intervalle attendu\n"

        # ===Interpretation du taux d'acceptation moyen===
        mean_acc = stats.get('mean_accept', 0)
        std_acc = stats.get('std_accept', 0.0)
        lowera , uppera = mean_acc - z*std_acc/n_root , mean_acc + z*std_acc/n_root

        report += f"\n- Taux d'acceptation moyen  : {mean_acc:.1%} vs {ideal_accept:.1%} attendu sous H₀ \n"
        report += f"- Intervalle de confiance à {(1-alpha):.0%} : [{lowera:.3%}, {uppera:.3%}]\n"

        if lowera > ideal_accept:
            acc_status = status.High
            report += "- Taux d'acceptation moyen  élevé : certains tests sont trop permissifs \n"
        elif uppera < ideal_accept:
            acc_status = status.Low
            report += "- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité\n"
        else:
            acc_status = status.Normal
            report += "- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests\n"

        if acc_status == p_value_status:
            if acc_status == status.Normal:
                report += "\n**Conclusion** : On accepte l'uniformité \n"
            if acc_status == status.High:
                report += "\n**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier \n"
            if acc_status == status.Low:
                report += "\n**Conclusion** : on rejette l'uniformité \n"
        else:
            if p_value_status == status.Low and acc_status == status.Normal:
                report += "\n**Conclusion** :Cela peut indiquer une instabilité du test, un problème de calibration ou des biais dans le calcul des p-values\n"
            if p_value_status == status.High and acc_status == status.Low:
                report += "\n**Conclusion** :Cela peut indiquer une instabilité du test, un problème de calibration ou des biais dans le calcul des p-values\n"
        return report

    def save_all(self, output_dir: Union[str, Path] = None):
        """
        Sauvegarde tous les résultats dans un dossier.
        """
        output_dir = f"results_{self.name}" if output_dir is None else output_dir
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        self.save_report(output_path)
        self.save_hists(output_path)
        self.save_figures(output_path)

    def save_report(self, output_path: Path) -> None:
        """Sauvegarde le rapport."""
        report_path = Path(output_path) / f"report_{self.name}.md"
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(self.generate_report())

    def save_hists(self, output_path: Path) -> None:
        """Sauvegarde l'historique des résultats."""
        output_path = Path(output_path)
        hist_path = output_path / f"history_{self.name}.csv"
        hist_test_path = output_path / f"history_by_test_{self.name}.csv"
        hist_gran_path = output_path / f"history_by_size_{self.name}.csv"
        self.hist_df.to_csv(hist_path, index=False)
        self.hist_test.to_csv(hist_test_path, index=False)
        self.hist_granularity.to_csv(hist_gran_path, index=False)

    def save_figures(self , output_dir: Path) -> None:
        """
        Sauvegarde les figures dans un dossier.
        """

        output_dir = f"figures_{self.name}" if output_dir is None else output_dir
        output_path = Path(output_dir)

        for by in ["Test", "window_size"]:
            for stat in ["mean_accept", "median_accept", "mean_p_value", "median_p_value"]:
                self.barplot_by(by=by, stat=stat,
                                show=False, save_path=output_path/f"bar_{stat}_by_{by}_{self.name}.png")

        for metric in ["accept","p_value"]:
            for func in ["mean", "median"]:
                self.heatmap_by(metric=metric, func=func,
                                show=False, save_path=output_path/f"heatmap_{metric}_{func}_{self.name}.png")

        for by in ["Test", "window_size"]:
            self.boxplot_by(by=by,
                            show=False,
                            save_path=output_path/f"boxplot_p_value_by_{by}_{self.name}.png")

    def barplot_by(self,
                   by:Literal["Test", "window_size"] = "Test",  stat:Literal["mean_accept", "median_accept","mean_p_value","median_p_value"] = "mean_accept",
                           show=True , save_path = None):
        """
        graphique en barres des taux d'acceptation moyen par test.
        """

        df = {"Test":self.hist_test,
              "window_size":self.hist_granularity}.get(by, self.hist_test)
        plt.figure(figsize=(12,8))
        sns.barplot(data=df , x=by, y=stat )
        plt.title(f"{stat} par {by} – {self.name}")
        plt.ylabel(f"{stat.replace('_', ' ').capitalize()}")
        plt.ylim(0, 1)
        plt.xticks(rotation=5)
        if save_path :
            plt.tight_layout()
            plt.savefig(save_path, bbox_inches='tight')
        if show:
            plt.show()
        plt.close()

    def heatmap_by(self,
                   metric:Literal["accept","p_value"]="accept",
                   func:Literal["mean","median"] = "mean",
                   show=True, save_path=None):
        """ Affiche une heatmap du taux d'acceptation moyen par test et granularité."""
        pivot = self.hist_df.pivot_table(index="window_size",
                                         columns="Test",
                                         values="accept",
                                         aggfunc=func)
        plt.figure(figsize=(12,8))
        sns.heatmap(pivot, annot=True, fmt=".1%"if metric=="accept" else ".2f",
                    cmap = 'Blues',vmin=0, vmax=1)
        plt.title(f" {func} {metric} par test et granularité - {self.name}")
        plt.xticks(rotation=5)
        if save_path:
            plt.tight_layout()
            plt.savefig(save_path, bbox_inches='tight')
        if show:
            plt.show()
        plt.close()

    def boxplot_by(self,
                   by:Literal["Test", "window_size"] = "Test",
                   show=True, save_path=None):
        """ Affiche un boxplot des taux d'acceptation moyen par test."""
        stat = "p_value"
        plt.figure(figsize=(12, 8))
        sns.boxplot(data=self.hist_df, x=by , y = stat)
        plt.title(f"{stat} par {by} - {self.name}")
        plt.ylabel(f"{stat.replace('_', ' ').capitalize()}")
        plt.ylim(0, 1)
        plt.xticks(rotation=5)
        if save_path:
            plt.tight_layout()
            plt.savefig(save_path, bbox_inches='tight')
        if show:
            plt.show()
        plt.close()

@dataclass
class GeneratorAnalyzer:
    """
    Classe permettant l'encapsulation des résultats d'analyse d'un générateur afin de les manipuler pour :
        * créer , afficher et sauvegarder  des graphiques
        * generation et sauvegarde d'un rapport d'interpretation

    Attributs
    -------
    generator :
        generateur à analyser
    test :
        liste des tests à appliquer
    n_repeat :
        nombre de répétitions pour l'évaluation du générateur
    seq_len :
        taille des séquences générées à chaque itération
    alpha :
        seuil de signification
    granularities :
        parmètres  fixant les tailles des fenêtres ; si ``NONE`` , on fait une analyse globale
    hist_df (pd.DataFrame):
        historique des calculs de l'analyse de la séquence
    stats (dict):
        résumé aggrégé des statistiques
    window_sizes (List[int]):
        liste des taille de sous séquence utilisées
    """
    generator : Generators
    tests:Optional[List[Tests]] = None
    alpha: float = 0.05
    n_repeat: int = 200
    seq_len: int = 10_000
    granularities: Optional[List[Union[int, float]]] = field(default_factory=lambda: [0.01, 0.5, 1.0])

    def __post_init__(self):
        self.name = str(self.generator)
        res = evaluate_generator(
            generator=self.generator,
            tests=self.tests,
            alpha=self.alpha,
            n_repeat=self.n_repeat,
            seq_len=self.seq_len,
            granularities=self.granularities
        )
        self.hist_df: pd.DataFrame = res.hist_df
        self.stats: Dict[str, float] = res.stats
        self.window_sizes: List[int] = res.window_sizes

    @property
    def hist_test(self)->pd.DataFrame:
        """ aggregation des résultats par test"""
        hist_count = self.hist_df.groupby("Test").size().reset_index(name='Count')
        hist = self.hist_df.copy().groupby("Test").agg(
            mean_p_value =("p_value","mean"),
            median_p_value = ("p_value","mean"),
            mean_accept = ("accept","mean"),
            median_accept = ("accept","median"),
            std_accept = ("accept","std"),
            std_p_value = ("p_value","std")
        ).reset_index()
        return hist.merge(hist_count, on="Test").sort_values("Test")

    @property
    def hist_granularity(self)->pd.DataFrame:
        """ aggregation des résultats par granularité"""
        hist_count = self.hist_df.groupby("window_size").size().reset_index(name='Count')
        # Calcul des statistiques par granularité
        hist = self.hist_df.copy().groupby("window_size").agg(
            mean_p_value = ("p_value","mean") ,
            median_p_value = ("p_value","median"),
            mean_accept = ("accept","mean"),
            median_accept = ("accept","median"),
            std_accept = ("accept","std"),
            std_p_value = ("p_value","std")
        ).reset_index()
        return hist.merge(hist_count, on="window_size").sort_values("window_size")

    @property
    def hist_iteration(self)->pd.DataFrame:
        """
        Aggregarion des résultats par itération.
        """
        hist_count = self.hist_df.groupby("Iteration").size().reset_index(name='Count')
        hist = self.hist_df.groupby("Iteration").agg(
            mean_p_value=("p_value", "mean"),
            median_p_value=("p_value", "median"),
            mean_accept=("accept", "mean"),
            median_accept=("accept", "median"),
            std_accept=("accept", "std"),
            std_p_value = ("p_value","std")
        ).reset_index()
        return hist.merge(hist_count, on="Iteration").sort_values("Iteration")

    def generate_report(self,gran:bool=True,test:bool=True) -> str:
        """
        Génère un rapport au format Markdown.
        """
        report = f"# Rapport d'analyse : {self.name}\n\n"

        # Statistiques globales
        report += "## Statistiques globales\n\n"
        stats_with_n = self.stats.copy()
        stats_with_n["n_tests"] = self.hist_df.shape[0]  # Ajouter le nombre de tests
        report += pd.DataFrame([stats_with_n]).T.rename(columns={0:"value"}).to_markdown() + "\n\n"

        report+=  self.interpret_stats(stats_with_n) + "\n\n"

        if test:
            # Analyse par test
            report += "\n## statistiques par test\n"
            report += self.hist_test.to_markdown(index=False)+ "\n\n"

            for _, row in self.hist_test.iterrows():
                stats_i = {
                    "mean_p_value": row['mean_p_value'],
                    "mean_accept": row['mean_accept'],
                    "std_accept": row['std_accept'],
                    "std_p_value": row['std_p_value'],
                    "alpha": self.stats.get('alpha', 0.05),
                    "n_tests": row['Count']
                }
                report += f"\n### Pour le {row['Test']} \n"
                report += self.interpret_stats(stats_i) + "\n\n"

        if gran:
            # resultat par granularité
            report += "\n## statistiques par granularité\n"
            report += self.hist_granularity.to_markdown(index=False) + "\n\n"

            for _, row in self.hist_granularity.iterrows():
                stats_i = {
                    "mean_p_value": row['mean_p_value'],
                    "mean_accept": row['mean_accept'],
                    "std_accept": row['std_accept'],
                    "std_p_value": row['std_p_value'],
                    "alpha": self.stats.get('alpha', 0.05),
                    "n_tests": row['Count']
                }
                report += f"\n### Pour size = {row['window_size']} \n"
                report += self.interpret_stats(stats_i) + "\n\n"



        return report
    @staticmethod
    def interpret_stats(stats: dict) -> str:
        """Interprétation des statistiques"""
        report =""
        n_tests = stats.get("n_tests" , 1) # Nombre total de tests effectués
        n_root = np.sqrt(n_tests)  # Racine carrée du nombre de tests pour les intervalles de confiance
        alpha = stats.get('alpha', 0.05)
        z = norm.ppf(1 - alpha / 2)  # Quantile pour l'intervalle de confiance
        ideal_p_value = 0.5  # P-value attendue sous H₀
        ideal_accept = 1 - alpha  # Taux d'acceptation attendu sous H₀


        # Interprétation de la p-value moyenne===
        mean_p = stats.get('mean_p_value', 0.5)
        std_p = stats.get('std_p_value', 0.0)
        lowerp , upperp = mean_p - z*std_p/n_root , mean_p + z*std_p/n_root
        report += f"- P-value moyenne globale : {mean_p:.3f} vs {ideal_p_value} attendu sous H₀ \n"
        report += f"- Intervalle de confiance à {(1-alpha):.0%} : [{lowerp:.3f}, {upperp:.3f}]\n"

        if lowerp > ideal_p_value:
            p_value_status = status.High
            report += "- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement\n"
        elif upperp < ideal_p_value:
            p_value_status = status.Low
            report += "- P-value moyenne trop faible : suspicion de non-conformité dans la séquence générée\n"
        else :
            p_value_status = status.Normal
            report += "- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests\n"

        # ===Interpretation du taux d'acceptation moyen===
        mean_acc = stats.get('mean_accept', 0)
        std_acc = stats.get('std_accept', 0.0)
        lowera , uppera = mean_acc - z*std_acc/n_root , mean_acc + z*std_acc/n_root

        report += f"\n- Taux d'acceptation moyen  : {mean_acc:.1%} vs {ideal_accept:.1%} attendu sous H₀ \n"
        report += f"- Intervalle de confiance à {(1-alpha):.0%} : [{lowera:.3%}, {uppera:.3%}]\n"

        if lowera > ideal_accept:
            acc_status = status.High
            report += "- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)\n"
        elif uppera < ideal_accept:
            acc_status = status.Low
            report += "- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée\n"
        else:
            acc_status = status.Normal
            report += "- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests\n"


        return report

    def save_all(self, output_dir: Union[str, Path] = None):
        """
        Sauvegarde tous les résultats dans un dossier.
        """
        output_dir = f"results_{self.name}" if output_dir is None else output_dir
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        self.save_report(output_path)
        self.save_hists(output_path)
        self.save_figures(output_path)

    def save_report(self, output_path: Path) -> None:
        """Sauvegarde le rapport."""
        report_path = Path(output_path) / f"report_{self.name}.md"
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(self.generate_report())

    def save_hists(self, output_path: Path) -> None:
        """Sauvegarde l'historique des résultats."""
        output_path = Path(output_path)
        hist_path = output_path / f"history_{self.name}.csv"
        hist_test_path = output_path / f"history_by_test_{self.name}.csv"
        hist_gran_path = output_path / f"history_by_size_{self.name}.csv"
        self.hist_df.to_csv(hist_path, index=False)
        self.hist_test.to_csv(hist_test_path, index=False)
        self.hist_granularity.to_csv(hist_gran_path, index=False)

    def save_figures(self , output_dir: Path) -> None:
        """
        Sauvegarde les figures dans un dossier.
        """

        output_dir = f"figures_{self.name}" if output_dir is None else output_dir
        output_path = Path(output_dir)
        for by in ["Test", "window_size"]:
            for stat in ["mean_accept", "mean_p_value", "std_accept"]:
                self.barplot_by(by=by, stat=stat,
                                show=False, save_path=output_path/f"bar_{stat}_by_{by}_{self.name}.png")

        for metric in ["accept","p_value"]:
            func ="mean"
            self.heatmap_by(metric=metric, func=func,
                            show=False, save_path=output_path/f"heatmap_{metric}_{func}_{self.name}.png")

        for by in ["Test", "window_size" , "Iteration"]:
            stat = "p_value"
            self.boxplot_by(by=by,
                            show=False, save_path=output_path/f"boxplot_{stat}_by_{by}_{self.name}.png")


    def barplot_by(self,
                   by:Literal["Test", "window_size"] = "Test",  stat:Literal["mean_accept", "median_accept","mean_p_value","median_p_value","std_accept"] = "mean_accept",
                           show=True , save_path = None):
        """
        graphique en barres des taux d'acceptation moyen par test.
        """

        df = {"Test":self.hist_test,
              "window_size":self.hist_granularity}.get(by, self.hist_test)
        plt.figure(figsize=(12,8))
        sns.barplot(data=df , x=by, y=stat )
        plt.title(f"{stat} par {by} – {self.name}")
        plt.ylabel(f"{stat.replace('_', ' ').capitalize()}")
        plt.ylim(0, 1)
        if save_path :
            plt.tight_layout()
            plt.savefig(save_path, bbox_inches='tight')
        if show:
            plt.show()
        plt.close()

    def heatmap_by(self,
                   metric:Literal["accept","p_value"]="accept",
                   func:Literal["mean","median","std"] = "mean",
                   show=True, save_path=None):
        """ Affiche une heatmap du taux d'acceptation moyen par test et granularité."""
        pivot = self.hist_df.pivot_table(index="window_size",
                                         columns="Test",
                                         values="accept",
                                         aggfunc=func)
        plt.figure(figsize=(12,8))
        sns.heatmap(pivot, annot=True, fmt=".2%"if metric=="accept" else ".2f",
                    cmap = 'Blues',vmin=0, vmax=1)
        plt.title(f" {func} {metric} par test et granularité - {self.name}")
        plt.xticks(rotation=5)
        if save_path:
            plt.tight_layout()
            plt.savefig(save_path, bbox_inches='tight')
        if show:
            plt.show()
        plt.close()

    def boxplot_by(self,
                   by:Literal["Test", "window_size"] = "Test",
                   show=True, save_path=None):
        """ Affiche un boxplot des taux d'acceptation moyen par test."""
        stat ="p_value"
        plt.figure(figsize=(12, 8))
        sns.boxplot(data=self.hist_df, x=by, y=stat)
        plt.title(f"{stat} par {by} - {self.name}")
        plt.ylabel(f"{stat.replace('_', ' ').capitalize()}")
        plt.ylim(0, 1)
        plt.xticks(rotation=5)
        if save_path:
            plt.tight_layout()
            plt.savefig(save_path, bbox_inches='tight')
        if show:
            plt.show()
        plt.close()

@dataclass
class ComparatorGenerator:
    """"Classe pour comparer plusieurs générateurs de nombres aléatoires."""
    generators: List[Generators]
    tests: List[Tests] = field(default_factory=lambda: [KSTest(),Chi2Test()])
    granularities: List[Union[int, float]] = field(default_factory= lambda:[0.01, 0.5, 1.0])
    alpha: float = field( default= 0.05)
    n_repeat: int = field( default= 100)
    seq_len: int = field(default= 10000)

    def __post_init__(self):
        self.results: dict[str, GeneratorAnalyzer] = self._run_evaluation()

    def _run_evaluation(self):
        """Évalue tous les générateurs si ce n’est pas déjà fait."""
        results = {}
        for gen in self.generators:
            name = str(gen)
            print(f"Évaluation de {name}...")
            result = GeneratorAnalyzer(
                generator=gen,
                tests=self.tests,
                granularities=self.granularities,
                n_repeat=self.n_repeat,
                seq_len=self.seq_len
            )
            results[name] = result

        return results

    def __str__(self) -> str:
        """Représentation string de la comparaison."""
        return f"ComparatorGenerator({', '.join(str(gen) for gen in self.generators)})"

    def to_stat_table(self) -> pd.DataFrame:
        """Retourne un tableau global (statistiques principales) avec les générateurs en colonnes."""
        data = {name: res.stats for name, res in self.results.items()}
        return pd.DataFrame(data)

    def to_aggregated_table(self,
                            by: Literal["Test", "window_size", "Iteration"] = "Test",
                            stats: List[str] = None) -> pd.DataFrame:
        """
        Retourne un tableau indexé par (groupe, mesure) et colonnes = générateurs
        """
        if stats is None:
            stats = ["mean_accept", "median_accept", "std_accept", "mean_p_value", "median_p_value"]

        all_tables = {}
        for name, res in self.results.items():
            df = {"Test": res.hist_test.set_index("Test"),
                  "window_size": res.hist_granularity.set_index("window_size"),
                  "Iteration": res.hist_iteration.set_index("Iteration")
                  }.get(by, res.hist_test)

            # Sélectionner uniquement les colonnes désirées
            df = df[[col for col in stats if col in df.columns]]
            # Pivot (multiindex)
            df.columns = pd.MultiIndex.from_product([[name], df.columns])
            all_tables[name] = df

        merged = pd.concat(all_tables.values(), axis=1)
        merged = merged.swaplevel(axis=1).sort_index(axis=1)
        return merged

    def generate_report(self, output_dir: Union[str, Path] = "comparisons"):
        """
        Génère un rapport Markdown résumant la comparaison.
        """
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)

        stat_table = self.to_stat_table().round(4)

        report = "# Rapport comparatif des générateurs\n\n"
        report += "## Statistiques globales\n\n"
        report += stat_table.to_markdown() + "\n\n"

        with open(output_path / f"report_{self}.md", "w", encoding="utf-8") as f:
            f.write(report)

    def save_all(self, output_dir: Union[str, Path] = "comparisons"):
        """
        Sauvegarde toutes les figures, historiques, rapports...
        """
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)

        self.generate_report(output_path)

        # Sauvegarde des historiques de chaque générateur
        for name, result in self.results.items():
            result.save_all(output_path / name)

        # Sauvegarde de graphiques comparatifs
        for stat in ["mean_accept", "mean_p_value"]:
            for by in ["Test", "window_size"]:
                self.compare_barplot(by=by, stat=stat,
                                     show=False,
                                     save_path=output_path / f"bar_{stat}_by_{by}.png")
                self.compare_boxplot(by=by, stat=stat,
                                     show=False,
                                     save_path=output_path / f"box_{stat}_by_{by}.png")


    def compare_barplot(self,
                        by: Literal["Test", "window_size"] = "Test",
                        stat: Literal["median_accept", "mean_accept"] = "mean_accept",
                        show: bool = True,
                        save_path: Union[str, None] = None):
        """
        Compare les taux d'acceptation (median ou moyen) entre les générateurs
        selon un critère donné (Test, window_size, Iteration).
        """
        all_dfs = []

        for name, res in self.results.items():
            if by == "Test":
                df = res.hist_test.copy()
                df["Group"] = df["Test"]
            elif by == "window_size":
                df = res.hist_granularity.copy()
                df["Group"] = df["window_size"]
            else:
                raise ValueError("'by' doit être 'Test'ou 'window_size'")

            df["Generator"] = name
            df["Value"] = df[stat]
            all_dfs.append(df[["Generator", "Group", "Value"]])

        merged_df = pd.concat(all_dfs, ignore_index=True)

        plt.figure(figsize=(12, 7))
        sns.barplot(data=merged_df, x="Group", y="Value", hue="Generator")
        plt.title(f"{stat} par {by}")
        plt.xlabel(by.capitalize())
        plt.ylim(0, 1)
        plt.xticks(rotation=5)
        plt.grid(True)
        plt.legend(title="Générateur")
        if save_path:
            plt.tight_layout()
            plt.savefig(save_path, bbox_inches="tight")
        if show:
            plt.show()
        plt.close()

    def compare_boxplot(self,
                        by: Literal["Test", "window_size"] = "Test",
                        stat: Literal["mean_p_value", "mean_accept"] = "mean_accept",
                        show: bool = True,
                        save_path: Union[str, None] = None):
        """
        Compare les taux d'acceptation/p_value moyen entre les générateurs
        selon un critère donné (Test, window_size).
        """
        all_dfs = []

        for name, res in self.results.items():
            if by == "Test":
                df = res.hist_test.copy()
                df["Group"] = df["Test"]
            elif by == "window_size":
                df = res.hist_granularity.copy()
                df["Group"] = df["window_size"]
            else:
                raise ValueError("'by' doit être 'Test'ou 'window_size'")

            df["Generator"] = name
            df["Value"] = df[stat]
            all_dfs.append(df[["Generator", "Group", "Value"]])


        merged_df = pd.concat(all_dfs, ignore_index=True)

        plt.figure(figsize=(12, 7))
        sns.boxplot(data=merged_df, x="Group", y="Value", hue="Generator")
        plt.title(f"{stat} par {by}")
        plt.xlabel(by.capitalize())
        plt.ylim(0, 1)
        plt.grid(True)
        plt.legend(title="Générateur")
        if save_path:
            plt.tight_layout()
            plt.savefig(save_path, bbox_inches="tight")
        if show:
            plt.show()
        plt.close()
