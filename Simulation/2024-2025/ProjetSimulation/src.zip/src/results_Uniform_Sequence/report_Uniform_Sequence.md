# Rapport d'analyse : Uniform_Sequence

## Statistiques globales

|                |    value |
|:---------------|---------:|
| mean_p_value   | 0.317799 |
| median_p_value | 0.317799 |
| std_p_value    | 0.440774 |
| mean_accept    | 0.5      |
| median_accept  | 0.5      |
| std_accept     | 0.707107 |
| n_tests        | 2        |

- P-value moyenne globale : 0.318 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [-0.293, 0.929]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [-47.998%, 147.998%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



## statistiques par test
| Test         |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test    |     0.00612485 |       0.00612485 |             0 |               0 |          nan |           nan |       1 |
| (nb_bins=10) |                |                  |               |                 |              |               |         |
| K-S_Test     |     0.629474   |       0.629474   |             1 |               1 |          nan |           nan |       1 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.006 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [nan, nan]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 0.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [nan%, nan%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour le K-S_Test 
- P-value moyenne globale : 0.629 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [nan, nan]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 100.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [nan%, nan%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|         10000 |       0.317799 |         0.317799 |           0.5 |             0.5 |     0.707107 |      0.440774 |       2 |


### Pour size = 10000.0 
- P-value moyenne globale : 0.318 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [-0.293, 0.929]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [-47.998%, 147.998%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests


