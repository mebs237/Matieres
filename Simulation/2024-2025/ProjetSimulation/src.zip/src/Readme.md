# Projet : Tests Statistiques pour Générateurs de Nombres Pseudo-Aléatoires

## Description
Ce projet implémente des tests statistiques pour évaluer la qualité des séquences de nombres et des générateurs de nombres pseudo-aléatoires uniformes entre 0 et 1. Il inclut des générateurs personnalisés utilisant une séquence de nombres en entré . Il implémente aussi les tests  du Chi-carré, du Gap,  du Poker, et d'autres.

## Structure du projet
- **Generators.py** : Implémente des générateurs de nombres pseudo-aléatoires, comme `PythonGenerator` (basé sur le générateur natif de Python) et `OurGenerator` (un générateur personnalisé).
- **Tests.py** : Contient des classes pour différents tests statistiques (Chi2, Gap, Poker, etc.).
- **Testing.py** : Orchestration des tests sur les générateurs.
-**Analysing.py** : une version améliorée et plus fine de Testing
- **main.py** : Point d'entrée principal pour exécuter les tests.
- **Utils.py** : fonctions auxilliaires utilisées pour les implémentations des tests statistiques


## Prérequis
- Python 3.8 ou supérieur
- Bibliothèques Python :
  - `numpy`
  - `scipy`


## Utilisation
1. Exécutez le fichier `main.py` pour lancer les études définies : python main.py

## Tests Statistiques Disponibles pour l'étude sont implémentés par les classes :
- **Chi2Test** : le test du chi carré
- **GapTest** : test du gap
- **PokerTest** : le test du poker
- **KSTest** : le test de Kolmogorov-Smirnov
- **MaximumTest** : les test des maximums
- **CouponCollectoreTest** : le test du collectionneur de coupons


## Contribution
Les contributions sont les bienvenues ! Veuillez soumettre une pull request ou ouvrir une issue pour toute suggestion ou problème.

## Licence
Ce projet est sous licence MIT. Consultez le fichier `LICENSE` pour plus d'informations.