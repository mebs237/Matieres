# Rapport d'analyse : ogen with Decimals groubed by 2

## Statistiques globales

|                 |        value |
|:----------------|-------------:|
| mean_p_value    |     0.602047 |
| mmedian_p_value |     0.637324 |
| std_p_value     |     0.312818 |
| mean_accept     |     0.262621 |
| median_accept   |     0        |
| std_accept      |     0.440069 |
| alpha           |     0.05     |
| n_tests         | 20600        |

- P-value moyenne globale : 0.602 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.598, 0.606]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 26.3% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [25.661%, 26.863%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.520802 |         0.520802 |     0.0275728 |               0 |     0.163761 |      0.305972 |    5150 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |       0.453226 |         0.453226 |     0.0275728 |               0 |     0.163761 |      0.270406 |    5150 |
| (nb_coupon=None)       |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.922076 |         0.922076 |     0.027767  |               0 |     0.164321 |      0.213    |    5150 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0.553442 |         0.553442 |     0.967573  |               1 |     0.177149 |      0.294803 |    5150 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.521 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.512, 0.529]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 2.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.310%, 3.205%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Coupon_Collector_Test 
(nb_coupon=None) 
- P-value moyenne globale : 0.453 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.446, 0.461]
- P-value moyenne trop faible : suspicion de non-conformité dans la séquence générée

- Taux d'acceptation moyen  : 2.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.310%, 3.205%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.922 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.916, 0.928]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 2.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.328%, 3.225%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le K-S_Test 
- P-value moyenne globale : 0.553 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.545, 0.561]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 96.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [96.273%, 97.241%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|            10 |       0.612201 |         0.650077 |         0.242 |               0 |     0.428305 |      0.312886 |   20000 |
|           500 |       0.503062 |         0.521719 |         0.94  |               1 |     0.237784 |      0.296137 |     400 |
|          1000 |       0.508592 |         0.503268 |         0.97  |               1 |     0.171015 |      0.294157 |     200 |


### Pour size = 10.0 
- P-value moyenne globale : 0.612 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.608, 0.617]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 24.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [23.606%, 24.794%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour size = 500.0 
- P-value moyenne globale : 0.503 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.474, 0.532]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 94.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [91.670%, 96.330%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour size = 1000.0 
- P-value moyenne globale : 0.509 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.468, 0.549]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 97.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [94.630%, 99.370%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests


