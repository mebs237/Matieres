# Rapport comparatif des générateurs

## Statistiques globales

|                 |   Python_Generator |   ogen with Decimals groubed by 2 |
|:----------------|-------------------:|----------------------------------:|
| mean_p_value    |             0.6059 |                            0.602  |
| mmedian_p_value |             0.6373 |                            0.6373 |
| std_p_value     |             0.3126 |                            0.3128 |
| mean_accept     |             0.2608 |                            0.2626 |
| median_accept   |             0      |                            0      |
| std_accept      |             0.4391 |                            0.4401 |
| alpha           |             0.05   |                            0.05   |

