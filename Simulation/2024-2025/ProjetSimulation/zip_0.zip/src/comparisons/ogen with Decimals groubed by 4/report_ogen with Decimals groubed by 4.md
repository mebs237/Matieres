# Rapport d'analyse : ogen with Decimals groubed by 4

## Statistiques globales

|                 |        value |
|:----------------|-------------:|
| mean_p_value    |     0.597605 |
| mmedian_p_value |     0.626289 |
| std_p_value     |     0.311378 |
| mean_accept     |     0.262282 |
| median_accept   |     0        |
| std_accept      |     0.439886 |
| alpha           |     0.05     |
| n_tests         | 20600        |

- P-value moyenne globale : 0.598 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.593, 0.602]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 26.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [25.627%, 26.829%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.450642 |         0.450642 |     0.0275728 |               0 |     0.163761 |      0.272374 |    5150 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |       0.473656 |         0.473656 |     0.0269903 |               0 |     0.162071 |      0.291042 |    5150 |
| (nb_coupon=None)       |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.918843 |         0.918843 |     0.027767  |               0 |     0.164321 |      0.211243 |    5150 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0.550917 |         0.550917 |     0.966796  |               1 |     0.179186 |      0.293455 |    5150 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.451 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.443, 0.458]
- P-value moyenne trop faible : suspicion de non-conformité dans la séquence générée

- Taux d'acceptation moyen  : 2.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.310%, 3.205%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Coupon_Collector_Test 
(nb_coupon=None) 
- P-value moyenne globale : 0.474 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.466, 0.482]
- P-value moyenne trop faible : suspicion de non-conformité dans la séquence générée

- Taux d'acceptation moyen  : 2.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.256%, 3.142%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.919 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.913, 0.925]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 2.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.328%, 3.225%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le K-S_Test 
- P-value moyenne globale : 0.551 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.543, 0.559]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 96.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [96.190%, 97.169%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|            10 |       0.609442 |         0.643807 |       0.24185 |               0 |     0.428215 |      0.312003 |   20000 |
|           500 |       0.473804 |         0.464273 |       0.935   |               1 |     0.246835 |      0.28045  |     400 |
|          1000 |       0.506385 |         0.521815 |       0.96    |               1 |     0.196451 |      0.283251 |     200 |


### Pour size = 10.0 
- P-value moyenne globale : 0.609 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.605, 0.614]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 24.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [23.592%, 24.778%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour size = 500.0 
- P-value moyenne globale : 0.474 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.446, 0.501]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 93.5% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [91.081%, 95.919%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour size = 1000.0 
- P-value moyenne globale : 0.506 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.467, 0.546]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 96.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [93.277%, 98.723%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests


