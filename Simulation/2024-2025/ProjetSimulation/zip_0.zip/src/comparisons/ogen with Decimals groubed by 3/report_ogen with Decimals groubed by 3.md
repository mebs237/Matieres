# Rapport d'analyse : ogen with Decimals groubed by 3

## Statistiques globales

|                 |        value |
|:----------------|-------------:|
| mean_p_value    |     0.614011 |
| mmedian_p_value |     0.6512   |
| std_p_value     |     0.307107 |
| mean_accept     |     0.262524 |
| median_accept   |     0        |
| std_accept      |     0.440017 |
| alpha           |     0.05     |
| n_tests         | 20600        |

- P-value moyenne globale : 0.614 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.610, 0.618]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 26.3% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [25.652%, 26.853%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.562948 |         0.562948 |     0.0283495 |               0 |     0.165985 |      0.294409 |    5150 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |       0.500418 |         0.500418 |     0.0267961 |               0 |     0.161503 |      0.304182 |    5150 |
| (nb_coupon=None)       |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.927236 |         0.927236 |     0.0283495 |               0 |     0.165985 |      0.195673 |    5150 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0.563643 |         0.563643 |     0.966602  |               1 |     0.179691 |      0.290223 |    5150 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.563 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.555, 0.571]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 2.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.382%, 3.288%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Coupon_Collector_Test 
(nb_coupon=None) 
- P-value moyenne globale : 0.500 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.492, 0.509]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 2.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.239%, 3.121%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.927 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.922, 0.933]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 2.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.382%, 3.288%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le K-S_Test 
- P-value moyenne globale : 0.564 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.556, 0.572]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 96.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [96.169%, 97.151%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|            10 |       0.621626 |         0.663006 |        0.2416 |               0 |     0.428064 |      0.308101 |   20000 |
|           500 |       0.537055 |         0.566688 |        0.95   |               1 |     0.218218 |      0.293222 |     400 |
|          1000 |       0.54873  |         0.557629 |        0.98   |               1 |     0.140351 |      0.276441 |     200 |


### Pour size = 10.0 
- P-value moyenne globale : 0.622 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.617, 0.626]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 24.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [23.567%, 24.753%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour size = 500.0 
- P-value moyenne globale : 0.537 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.508, 0.566]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 95.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [92.862%, 97.138%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour size = 1000.0 
- P-value moyenne globale : 0.549 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.510, 0.587]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 98.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [96.055%, 99.945%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)


