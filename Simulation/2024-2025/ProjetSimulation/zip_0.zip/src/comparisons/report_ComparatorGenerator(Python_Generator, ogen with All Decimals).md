# Rapport comparatif des générateurs

## Statistiques globales

|                 |   Python_Generator |   ogen with All Decimals |
|:----------------|-------------------:|-------------------------:|
| mean_p_value    |             0.6001 |                   0.6045 |
| mmedian_p_value |             0.6316 |                   0.6382 |
| std_p_value     |             0.3114 |                   0.3121 |
| mean_accept     |             0.2617 |                   0.2617 |
| median_accept   |             0      |                   0      |
| std_accept      |             0.4396 |                   0.4396 |
| alpha           |             0.05   |                   0.05   |

