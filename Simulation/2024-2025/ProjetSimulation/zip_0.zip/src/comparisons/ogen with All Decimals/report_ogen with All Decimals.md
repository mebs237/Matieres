# Rapport d'analyse : ogen with All Decimals

## Statistiques globales

|                 |        value |
|:----------------|-------------:|
| mean_p_value    |     0.604487 |
| mmedian_p_value |     0.638249 |
| std_p_value     |     0.312134 |
| mean_accept     |     0.261699 |
| median_accept   |     0        |
| std_accept      |     0.43957  |
| alpha           |     0.05     |
| n_tests         | 20600        |

- P-value moyenne globale : 0.604 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.600, 0.609]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 26.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [25.570%, 26.770%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.512733 |         0.512733 |     0.0267961 |               0 |     0.161503 |      0.294037 |    5150 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |       0.47046  |         0.47046  |     0.0267961 |               0 |     0.161503 |      0.299309 |    5150 |
| (nb_coupon=None)       |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.925159 |         0.925159 |     0.0281553 |               0 |     0.165433 |      0.202888 |    5150 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0.554961 |         0.554961 |     0.965049  |               1 |     0.183675 |      0.294359 |    5150 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.513 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.505, 0.521]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 2.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.239%, 3.121%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Coupon_Collector_Test 
(nb_coupon=None) 
- P-value moyenne globale : 0.470 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.462, 0.479]
- P-value moyenne trop faible : suspicion de non-conformité dans la séquence générée

- Taux d'acceptation moyen  : 2.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.239%, 3.121%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.925 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.920, 0.931]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 2.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.364%, 3.267%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le K-S_Test 
- P-value moyenne globale : 0.555 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.547, 0.563]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 96.5% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [96.003%, 97.006%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|            10 |       0.615141 |         0.655249 |        0.2416 |               0 |     0.428064 |      0.312057 |   20000 |
|           500 |       0.489258 |         0.467459 |        0.925  |               1 |     0.263721 |      0.294554 |     400 |
|          1000 |       0.528568 |         0.553548 |        0.945  |               1 |     0.228552 |      0.292246 |     200 |


### Pour size = 10.0 
- P-value moyenne globale : 0.615 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.611, 0.619]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 24.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [23.567%, 24.753%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour size = 500.0 
- P-value moyenne globale : 0.489 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.460, 0.518]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 92.5% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [89.916%, 95.084%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour size = 1000.0 
- P-value moyenne globale : 0.529 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.488, 0.569]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 94.5% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [91.332%, 97.668%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests


