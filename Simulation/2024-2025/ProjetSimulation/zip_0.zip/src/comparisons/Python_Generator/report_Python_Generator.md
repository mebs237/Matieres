# Rapport d'analyse : Python_Generator

## Statistiques globales

|                 |        value |
|:----------------|-------------:|
| mean_p_value    |     0.596769 |
| mmedian_p_value |     0.622686 |
| std_p_value     |     0.313447 |
| mean_accept     |     0.261893 |
| median_accept   |     0        |
| std_accept      |     0.439675 |
| alpha           |     0.05     |
| n_tests         | 20600        |

- P-value moyenne globale : 0.597 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.592, 0.601]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 26.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [25.589%, 26.790%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.463668 |         0.463668 |     0.0271845 |               0 |     0.162636 |      0.284398 |    5150 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |       0.476479 |         0.476479 |     0.0269903 |               0 |     0.162071 |      0.291654 |    5150 |
| (nb_coupon=None)       |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.919651 |         0.919651 |     0.0285437 |               0 |     0.166536 |      0.214385 |    5150 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0.54697  |         0.54697  |     0.964854  |               1 |     0.184166 |      0.294208 |    5150 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.464 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.456, 0.471]
- P-value moyenne trop faible : suspicion de non-conformité dans la séquence générée

- Taux d'acceptation moyen  : 2.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.274%, 3.163%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Coupon_Collector_Test 
(nb_coupon=None) 
- P-value moyenne globale : 0.476 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.469, 0.484]
- P-value moyenne trop faible : suspicion de non-conformité dans la séquence générée

- Taux d'acceptation moyen  : 2.7% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.256%, 3.142%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.920 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.914, 0.926]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 2.9% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [2.400%, 3.309%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour le K-S_Test 
- P-value moyenne globale : 0.547 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.539, 0.555]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 96.5% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [95.982%, 96.988%]
- Taux d'acceptation moyen  élevé : possible sur-ajustement(des séquences aux tests) ou biais (dans la logique des tests)



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|            10 |       0.609059 |         0.642502 |       0.24135 |               0 |     0.427913 |      0.313649 |   20000 |
|           500 |       0.48061  |         0.474199 |       0.9425  |               1 |     0.233087 |      0.291808 |     400 |
|          1000 |       0.474992 |         0.473614 |       0.955   |               1 |     0.207824 |      0.274664 |     200 |


### Pour size = 10.0 
- P-value moyenne globale : 0.609 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.605, 0.613]
- P-value moyenne  élevée : suspicion de biais  ou sur-ajustement

- Taux d'acceptation moyen  : 24.1% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [23.542%, 24.728%]
- Taux d'acceptation moyen faible : suspicion de non uniformité dans la séquence générée



### Pour size = 500.0 
- P-value moyenne globale : 0.481 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.452, 0.509]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 94.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [91.966%, 96.534%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests



### Pour size = 1000.0 
- P-value moyenne globale : 0.475 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.437, 0.513]
- P-value moyenne dans l'intervalle attendu : séquence conforme aux tests

- Taux d'acceptation moyen  : 95.5% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [92.620%, 98.380%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests


