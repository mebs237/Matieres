# Rapport d'analyse : Decimals groubed by 3

## Statistiques globales

|                |      value |
|:---------------|-----------:|
| mean_p_value   |   0.375827 |
| median_p_value |   0.342547 |
| std_p_value    |   0.345375 |
| mean_accept    |   0.5      |
| median_accept  |   0.5      |
| std_accept     |   0.502247 |
| n_tests        | 112        |

- P-value moyenne globale : 0.376 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.312, 0.440]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [40.698%, 59.302%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.567982 |         0.567982 |             1 |               1 |            0 |      0.296189 |      28 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |     nan        |       nan        |             0 |               0 |            0 |    nan        |      28 |
| (nb_coupon=10)         |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.5595   |         0.5595   |             1 |               1 |            0 |      0.243323 |      28 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0        |         0        |             0 |               0 |            0 |      0        |      28 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.568 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.458, 0.678]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 100.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [100.000%, 100.000%]
- Taux d'acceptation moyen  élevé : certains tests sont trop permissifs 

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le Coupon_Collector_Test 
(nb_coupon=10) 
- P-value moyenne globale : nan vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [nan, nan]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 0.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000%, 0.000%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.559 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.469, 0.650]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 100.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [100.000%, 100.000%]
- Taux d'acceptation moyen  élevé : certains tests sont trop permissifs 

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le K-S_Test 
- P-value moyenne globale : 0.000 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000, 0.000]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 0.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000%, 0.000%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|         33333 |       0.396224 |         0.3643   |           0.5 |             0.5 |     0.503155 |      0.357467 |      80 |
|        133333 |       0.311651 |         0.17245  |           0.5 |             0.5 |     0.512989 |      0.330181 |      20 |
|        333333 |       0.414648 |         0.533585 |           0.5 |             0.5 |     0.534522 |      0.335028 |       8 |
|        666667 |       0.211136 |         0.194507 |           0.5 |             0.5 |     0.57735  |      0.219923 |       4 |


### Pour size = 33333.0 
- P-value moyenne globale : 0.396 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.318, 0.475]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [38.974%, 61.026%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 133333.0 
- P-value moyenne globale : 0.312 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.167, 0.456]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [27.518%, 72.482%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 333333.0 
- P-value moyenne globale : 0.415 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.182, 0.647]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [12.960%, 87.040%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 666667.0 
- P-value moyenne globale : 0.211 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [-0.004, 0.427]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [-6.579%, 106.579%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 


