# Rapport d'analyse : All Decimals

## Statistiques globales

|                |      value |
|:---------------|-----------:|
| mean_p_value   |   0.356417 |
| median_p_value |   0.293993 |
| std_p_value    |   0.314843 |
| mean_accept    |   0.714286 |
| median_accept  |   1        |
| std_accept     |   0.453784 |
| n_tests        | 112        |

- P-value moyenne globale : 0.356 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.298, 0.415]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 71.4% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [63.025%, 79.833%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.445926 |         0.445926 |      0.928571 |               1 |     0.262265 |      0.275523 |      28 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |       0.468677 |         0.468677 |      1        |               1 |     0        |      0.25045  |      28 |
| (nb_coupon=10)         |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.511065 |         0.511065 |      0.928571 |               1 |     0.262265 |      0.301602 |      28 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0        |         0        |      0        |               0 |     0        |      0        |      28 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.446 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.344, 0.548]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 92.9% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [83.143%, 102.571%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le Coupon_Collector_Test 
(nb_coupon=10) 
- P-value moyenne globale : 0.469 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.376, 0.561]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 100.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [100.000%, 100.000%]
- Taux d'acceptation moyen  élevé : certains tests sont trop permissifs 

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.511 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.399, 0.623]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 92.9% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [83.143%, 102.571%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le K-S_Test 
- P-value moyenne globale : 0.000 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000, 0.000]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 0.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000%, 0.000%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|    100000     |       0.366962 |         0.301077 |        0.7125 |               1 |     0.455452 |      0.317909 |      80 |
|    400000     |       0.356112 |         0.368373 |        0.7    |               1 |     0.470162 |      0.331987 |      20 |
|         1e+06 |       0.264689 |         0.214151 |        0.75   |               1 |     0.46291  |      0.314379 |       8 |
|         2e+06 |       0.330503 |         0.418292 |        0.75   |               1 |     0.5      |      0.226539 |       4 |


### Pour size = 100000.0 
- P-value moyenne globale : 0.367 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.297, 0.437]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 71.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [61.270%, 81.230%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 400000.0 
- P-value moyenne globale : 0.356 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.211, 0.502]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 70.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [49.395%, 90.605%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 1000000.0 
- P-value moyenne globale : 0.265 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.047, 0.483]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 75.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [42.923%, 107.077%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 2000000.0 
- P-value moyenne globale : 0.331 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.108, 0.553]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 75.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [26.001%, 123.999%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 


