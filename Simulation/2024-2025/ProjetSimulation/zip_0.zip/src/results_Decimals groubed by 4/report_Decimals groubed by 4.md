# Rapport d'analyse : Decimals groubed by 4

## Statistiques globales

|                |      value |
|:---------------|-----------:|
| mean_p_value   |   0.423637 |
| median_p_value |   0.296916 |
| std_p_value    |   0.420752 |
| mean_accept    |   0.473214 |
| median_accept  |   0        |
| std_accept     |   0.501526 |
| n_tests        | 112        |

- P-value moyenne globale : 0.424 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.346, 0.502]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 47.3% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [38.033%, 56.610%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.844644 |         0.844644 |      1        |               1 |      0       |      0.284285 |      28 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |     nan        |       nan        |      0        |               0 |      0       |    nan        |      28 |
| (nb_coupon=10)         |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.426268 |         0.426268 |      0.892857 |               1 |      0.31497 |      0.305709 |      28 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0        |         0        |      0        |               0 |      0       |      0        |      28 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.845 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.739, 0.950]
- P-value moyenne  élevée : sur-ajustement probable ou biais dans l'ensemble des tests utilisé 

- Taux d'acceptation moyen  : 100.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [100.000%, 100.000%]
- Taux d'acceptation moyen  élevé : certains tests sont trop permissifs 

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le Coupon_Collector_Test 
(nb_coupon=10) 
- P-value moyenne globale : nan vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [nan, nan]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 0.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000%, 0.000%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.426 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.313, 0.540]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 89.3% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [77.619%, 100.952%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le K-S_Test 
- P-value moyenne globale : 0.000 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000, 0.000]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 0.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000%, 0.000%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|         25000 |       0.481484 |         0.417286 |        0.4625 |             0   |     0.501737 |      0.447674 |      80 |
|        100000 |       0.339675 |         0.271624 |        0.5    |             0.5 |     0.512989 |      0.343402 |      20 |
|        250000 |       0.196048 |         0.149192 |        0.5    |             0.5 |     0.534522 |      0.252878 |       8 |
|        500000 |       0.141708 |         0.13254  |        0.5    |             0.5 |     0.57735  |      0.146508 |       4 |


### Pour size = 25000.0 
- P-value moyenne globale : 0.481 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.383, 0.580]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 46.2% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [35.255%, 57.245%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 100000.0 
- P-value moyenne globale : 0.340 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.189, 0.490]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [27.518%, 72.482%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 250000.0 
- P-value moyenne globale : 0.196 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.021, 0.371]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [12.960%, 87.040%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 500000.0 
- P-value moyenne globale : 0.142 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [-0.002, 0.285]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [-6.579%, 106.579%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 


