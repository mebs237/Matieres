# Rapport d'analyse : Decimals groubed by 2

## Statistiques globales

|                |      value |
|:---------------|-----------:|
| mean_p_value   |   0.371413 |
| median_p_value |   0.291087 |
| std_p_value    |   0.356419 |
| mean_accept    |   0.491071 |
| median_accept  |   0        |
| std_accept     |   0.502167 |
| n_tests        | 112        |

- P-value moyenne globale : 0.371 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.305, 0.437]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 49.1% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [39.807%, 58.407%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



## statistiques par test
| Test                   |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|:-----------------------|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
| Chi2_Test              |       0.611544 |         0.611544 |      0.964286 |               1 |     0.188982 |      0.292827 |      28 |
| (nb_bins=10)           |                |                  |               |                 |              |               |         |
| Coupon_Collector_Test  |     nan        |       nan        |      0        |               0 |     0        |    nan        |      28 |
| (nb_coupon=10)         |                |                  |               |                 |              |               |         |
| Gap_Test               |       0.502694 |         0.502694 |      1        |               1 |     0        |      0.289893 |      28 |
| ([ 0.1 , 0.4 ])        |                |                  |               |                 |              |               |         |
| K-S_Test               |       0        |         0        |      0        |               0 |     0        |      0        |      28 |


### Pour le Chi2_Test 
(nb_bins=10) 
- P-value moyenne globale : 0.612 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.503, 0.720]
- P-value moyenne  élevée : sur-ajustement probable ou biais dans l'ensemble des tests utilisé 

- Taux d'acceptation moyen  : 96.4% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [89.429%, 103.428%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le Coupon_Collector_Test 
(nb_coupon=10) 
- P-value moyenne globale : nan vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [nan, nan]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 0.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000%, 0.000%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le Gap_Test
([ 0.1 , 0.4 ]) 
- P-value moyenne globale : 0.503 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.395, 0.610]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 100.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [100.000%, 100.000%]
- Taux d'acceptation moyen  élevé : certains tests sont trop permissifs 

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour le K-S_Test 
- P-value moyenne globale : 0.000 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000, 0.000]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 0.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [0.000%, 0.000%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



## statistiques par granularité
|   window_size |   mean_p_value |   median_p_value |   mean_accept |   median_accept |   std_accept |   std_p_value |   Count |
|--------------:|---------------:|-----------------:|--------------:|----------------:|-------------:|--------------:|--------:|
|     50000     |       0.396738 |         0.310297 |        0.4875 |             0   |     0.502997 |      0.366414 |      80 |
|    200000     |       0.373197 |         0.302437 |        0.5    |             0.5 |     0.512989 |      0.383675 |      20 |
|    500000     |       0.185388 |         0.186308 |        0.5    |             0.5 |     0.534522 |      0.181043 |       8 |
|         1e+06 |       0.228044 |         0.264612 |        0.5    |             0.5 |     0.57735  |      0.212138 |       4 |


### Pour size = 50000.0 
- P-value moyenne globale : 0.397 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.316, 0.477]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 48.8% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [37.728%, 59.772%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 200000.0 
- P-value moyenne globale : 0.373 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.205, 0.541]
- P-value moyenne dans l'intervalle attendu

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [27.518%, 72.482%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 500000.0 
- P-value moyenne globale : 0.185 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.060, 0.311]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [12.960%, 87.040%]
- Taux d'acceptation moyen faible : rejet fréquent de l'uniformité

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 



### Pour size = 1000000.0 
- P-value moyenne globale : 0.228 vs 0.5 attendu sous H₀ 
- Intervalle de confiance à 95% : [0.020, 0.436]
- P-value moyenne faible : rejet fréquent de l'uniformité

- Taux d'acceptation moyen  : 50.0% vs 95.0% attendu sous H₀ 
- Intervalle de confiance à 95% : [-6.579%, 106.579%]
- Taux d'acceptation moyen dans l'intervalle attendu : séquence conforme aux tests

**Conclusion** : On accepte l'uniformité 

**Conclusion** : la séquence est sur-ajustée ou le/l'un des test(s) est(sont) biaisé(s) , on accept l'uniformité mais faudra vérifier 

**Conclusion** : on rejette l'uniformité 


